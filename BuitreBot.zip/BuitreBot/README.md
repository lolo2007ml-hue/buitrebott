# Buitre Bot

App Android que mira la pantalla y juega sola al juego de los buitres:
- Buitre **abajo** → toca la flecha de arriba (**salta**).
- Buitre **arriba** → mantiene apretada la flecha de abajo (**se agacha**).

Cómo funciona: captura la pantalla (MediaProjection), busca la cabeza del buitre con OpenCV
(template matching), calcula en cuánto tiempo llega al personaje y hace el toque con un
servicio de accesibilidad.

## Estado
- La **detección y la lógica** se probaron sobre tu video (`herramientas/probar_deteccion.py`).
- La app **no se compiló ni se probó en un celular real**: puede necesitar algún ajuste.

## Cómo obtener el APK
**Opción A – Android Studio (PC)**
1. Instalá Android Studio. 2. `File > Open` y elegí esta carpeta (`BuitreBot`).
3. Esperá a que sincronice (descarga OpenCV solo). 4. Conectá el celu con depuración USB y apretá ▶ Run.
   O `Build > Build APK(s)` para generar el APK.

**Opción B – GitHub (sin instalar nada)**
1. Subí esta carpeta a un repositorio nuevo. 2. Pestaña *Actions* > *Compilar APK* > *Run workflow*.
3. Cuando termine, bajá el artefacto `BuitreBot-apk` e instalalo en el celu.

## Cómo usarla
1. Abrí **Buitre Bot** > "Activar accesibilidad" > Buitre Bot (toques) > Activar.
   (Android 13+ si está bloqueado: Ajustes > Apps > Buitre Bot > ⋮ > *Permitir ajustes restringidos*.)
2. "Iniciar bot" y aceptá la captura de pantalla.
3. Abrí el juego **en horizontal** y tocá INICIO. El bot hace el resto.
4. Para parar: "Detener bot".

## Ajustes (en `BotService.kt`, arriba de todo)
- Salta tarde → subí `JUMP_TTC` (ej. 0.38). Salta temprano → bajala (ej. 0.28).
- Se agacha tarde/temprano → `DUCK_TTC`.
- Los botones y la zona del juego están medidos para una pantalla de **1600x720** (la de tu video).
  Si tu pantalla tiene otra proporción, hay que re-medir `GAME_X/Y`, `PLAYER_X`, `UP_X/Y`, `DOWN_X/Y`.

## Limitaciones conocidas
- Si el juego tiene ranking o premios, un bot puede romper sus reglas.
- Asume que agacharse = mantener apretado el botón (así lo hiciste en el video).
- Los buitres que vuelan a media altura y en lo alto se tratan igual (ambos → agacharse).
