"""
Prueba la detección de buitres sobre un video de pantalla del juego (1600x720),
usando la misma lógica que la app. Imprime cuándo saltaría / se agacharía.

Uso:  python probar_deteccion.py mi_video.mp4
Necesita:  pip install opencv-python numpy
"""
import sys, os
import cv2

GAME_X, GAME_Y, SEARCH_W, SEARCH_H = 24, 168, 740, 322
PLAYER_X, LOW_Y = 158, 268
SPEED, JUMP_TTC, DUCK_TTC = 460.0, 0.33, 0.55
HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(HERE, "..", "app", "src", "main", "assets")
TPL = [cv2.imread(os.path.join(ASSETS, n)) for n in ("t1.png", "t2.png")]


def detect(roi):
    out = []
    for t in TPL:
        r = cv2.matchTemplate(roi, t, cv2.TM_CCOEFF_NORMED)
        for _ in range(4):
            _, mx, _, loc = cv2.minMaxLoc(r)
            if mx < 0.70:
                break
            cx, cy = loc[0] + t.shape[1] // 2, loc[1] + t.shape[0] // 2
            if all(abs(o[0] - cx) >= 40 or abs(o[1] - cy) >= 30 for o in out):
                out.append((cx, cy))
            x, y = loc
            r[max(0, y - 30):y + 30, max(0, x - 50):x + 50] = -1
    return out


cap = cv2.VideoCapture(sys.argv[1])
fps = cap.get(cv2.CAP_PROP_FPS) or 30
step = max(1, round(fps / 10))          # ~10 análisis por segundo
i, last_jump, duck_until, ducking = 0, -9, -9, False
while True:
    ok, frame = cap.read()
    if not ok:
        break
    if i % step == 0:
        t = i / fps
        roi = frame[GAME_Y:GAME_Y + SEARCH_H, GAME_X:GAME_X + SEARCH_W]
        dets = detect(roi)
        in_air = t - last_jump < 0.75
        jumped = False
        if not in_air:
            low = [d for d in dets if d[1] > LOW_Y and d[0] - PLAYER_X > -40]
            if low and (min(low)[0] - PLAYER_X) / SPEED <= JUMP_TTC:
                last_jump, jumped, duck_until = t, True, -9
                print(f"{t:6.2f}s  SALTAR      (buitre abajo)")
            high = [d for d in dets if d[1] <= LOW_Y and d[0] - PLAYER_X > -100]
            if not jumped and high and (min(high)[0] - PLAYER_X) / SPEED <= DUCK_TTC:
                duck_until = t + 0.15
        duck = t < duck_until and not jumped
        if duck and not ducking:
            print(f"{t:6.2f}s  AGACHARSE   (buitre arriba)")
        if ducking and not duck:
            print(f"{t:6.2f}s  soltar agacharse")
        ducking = duck
    i += 1
