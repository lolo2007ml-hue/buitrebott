package com.buitrebot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.WindowManager
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.core.Rect as CvRect
import org.opencv.core.Size as CvSize
import org.opencv.imgproc.Imgproc

/**
 * Captura la pantalla, busca la cabeza de los buitres (template matching con OpenCV)
 * y toca el botón de saltar (buitre abajo) o mantiene el de agacharse (buitre arriba).
 */
class BotService : Service() {

    companion object {
        @Volatile var status: String = "Detenido"

        // ---- Todo en coordenadas de una pantalla de referencia 1600x720 (la de tu video) ----
        const val REF_W = 1600
        const val REF_H = 720

        // Zona del juego (esquina sup. izq. y tamaño de la zona donde buscamos buitres)
        const val GAME_X = 24
        const val GAME_Y = 168
        const val SEARCH_W = 740
        const val SEARCH_H = 322

        // Posición del personaje dentro de la zona del juego
        const val PLAYER_X = 158f

        // Botones (en pantalla de referencia)
        const val UP_X = 89f;     const val UP_Y = 641f
        const val DOWN_X = 1423f; const val DOWN_Y = 646f

        // Altura (dentro de la zona del juego) que separa "abajo" de "arriba"
        const val LOW_LANE_MIN_Y = 268

        // Ajustes finos (podés tocarlos si salta muy tarde / muy temprano)
        const val MATCH_THRESHOLD = 0.70
        const val DEFAULT_SPEED = 460f      // px/seg de los buitres si todavía no medimos
        const val JUMP_TTC = 0.33f          // saltar cuando faltan ~0.33 s para llegar al personaje
        const val DUCK_TTC = 0.55f          // agacharse cuando faltan ~0.55 s
        const val DUCK_RELEASE_DX = -100f   // soltar cuando el buitre ya pasó
        const val JUMP_LOCK_MS = 750L       // lo que dura un salto en el aire
    }

    private class Det(val x: Float, val y: Float, val score: Double) {
        val low get() = y > LOW_LANE_MIN_Y
    }

    @Volatile private var running = false
    private var thread: Thread? = null
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var curW = 0
    private var curH = 0

    private lateinit var templates: List<Mat>
    private var speed = DEFAULT_SPEED
    private var prevDets: List<Det> = emptyList()
    private var prevT = 0L
    private var lastJump = 0L
    private var duckUntil = 0L
    private var jumps = 0
    private var ducks = 0
    private var wasDucking = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || running) return START_NOT_STICKY

        val ch = "bot"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(ch, "Buitre Bot", NotificationManager.IMPORTANCE_LOW))
        val notif = Notification.Builder(this, ch)
            .setContentTitle("Buitre Bot activo")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, notif)
        }

        if (!OpenCVLoader.initLocal()) {
            status = "Error: no se pudo cargar OpenCV"
            stopSelf(); return START_NOT_STICKY
        }
        templates = listOf("t1.png", "t2.png").map { loadTemplate(it) }

        val code = intent.getIntExtra("code", 0)
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>("data")
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data!!)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, Handler(Looper.getMainLooper()))

        running = true
        thread = Thread { loop() }.also { it.start() }
        status = "Bot activo. Abrí el juego en horizontal."
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        thread?.join(500)
        TapService.instance?.holdStop()
        vd?.release(); reader?.close(); projection?.stop()
        status = "Detenido"
        super.onDestroy()
    }

    private fun loadTemplate(name: String): Mat {
        val bmp = assets.open(name).use { BitmapFactory.decodeStream(it) }
        val rgba = Mat(); Utils.bitmapToMat(bmp, rgba)
        val bgr = Mat(); Imgproc.cvtColor(rgba, bgr, Imgproc.COLOR_RGBA2BGR)
        return bgr
    }

    private fun ensureCapture() {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        val w = dm.widthPixels; val h = dm.heightPixels
        if (reader != null && w == curW && h == curH) return
        reader?.close()
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        if (vd == null) {
            vd = projection!!.createVirtualDisplay(
                "buitrebot", w, h, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
            )
        } else {
            vd!!.resize(w, h, dm.densityDpi)
            vd!!.surface = r.surface
        }
        reader = r; curW = w; curH = h
    }

    private fun loop() {
        val rgba = Mat(); val bgr = Mat()
        var padded: Bitmap? = null
        var frames = 0; var fpsT = SystemClock.elapsedRealtime(); var fps = 0
        while (running) {
            try {
                ensureCapture()
                val img = reader?.acquireLatestImage()
                if (img == null) { Thread.sleep(8); continue }
                val w = img.width; val h = img.height
                val pl = img.planes[0]
                val pw = pl.rowStride / pl.pixelStride
                if (padded == null || padded.width != pw || padded.height != h) {
                    padded = Bitmap.createBitmap(pw, h, Bitmap.Config.ARGB_8888)
                }
                val bmp = padded!!
                bmp.copyPixelsFromBuffer(pl.buffer)
                img.close()
                val now = SystemClock.elapsedRealtime()

                if (w < h) { status = "Poné el juego en horizontal"; continue }

                val frame = if (pw != w) Bitmap.createBitmap(bmp, 0, 0, w, h) else bmp
                Utils.bitmapToMat(frame, rgba)
                if (w != REF_W || h != REF_H) {
                    Imgproc.resize(rgba, rgba, CvSize(REF_W.toDouble(), REF_H.toDouble()), 0.0, 0.0, Imgproc.INTER_AREA)
                }
                val roi = rgba.submat(CvRect(GAME_X, GAME_Y, SEARCH_W, SEARCH_H))
                Imgproc.cvtColor(roi, bgr, Imgproc.COLOR_RGBA2BGR)
                roi.release()

                val dets = detect(bgr)
                decide(dets, now)

                frames++
                if (now - fpsT >= 1000) { fps = frames; frames = 0; fpsT = now }
                val near = dets.filter { it.x > PLAYER_X - 100 }.minByOrNull { it.x }
                status = "Activo ($fps fps)\nSaltos: $jumps  Agachadas: $ducks\n" +
                    (if (near == null) "Buitre: ninguno" else
                        "Buitre: ${if (near.low) "ABAJO -> saltar" else "ARRIBA -> agacharse"} x=${near.x.toInt()}") +
                    "\nVelocidad: ${speed.toInt()} px/s"
            } catch (e: Exception) {
                status = "Error: ${e.javaClass.simpleName} ${e.message}"
                try { Thread.sleep(200) } catch (_: InterruptedException) {}
            }
        }
    }

    private fun detect(bgr: Mat): List<Det> {
        val out = ArrayList<Det>()
        for (t in templates) {
            val res = Mat()
            Imgproc.matchTemplate(bgr, t, res, Imgproc.TM_CCOEFF_NORMED)
            for (k in 0 until 4) {
                val mm = Core.minMaxLoc(res)
                if (mm.maxVal < MATCH_THRESHOLD) break
                val cx = (mm.maxLoc.x + t.cols() / 2.0).toFloat()
                val cy = (mm.maxLoc.y + t.rows() / 2.0).toFloat()
                if (out.none { Math.abs(it.x - cx) < 40 && Math.abs(it.y - cy) < 30 }) out.add(Det(cx, cy, mm.maxVal))
                // borrar el vecindario para buscar el siguiente
                val x0 = Math.max(0, (mm.maxLoc.x - 50).toInt()); val x1 = Math.min(res.cols(), (mm.maxLoc.x + 50).toInt())
                val y0 = Math.max(0, (mm.maxLoc.y - 30).toInt()); val y1 = Math.min(res.rows(), (mm.maxLoc.y + 30).toInt())
                if (x1 > x0 && y1 > y0) {
                    val sub = res.submat(y0, y1, x0, x1)
                    sub.setTo(org.opencv.core.Scalar(-1.0))
                    sub.release()
                }
            }
            res.release()
        }
        return out
    }

    private fun decide(dets: List<Det>, now: Long) {
        // medir velocidad real de los buitres (px/seg)
        val dt = (now - prevT) / 1000f
        if (prevT > 0 && dt in 0.01f..0.2f) {
            for (d in dets) {
                val p = prevDets.filter { it.low == d.low && Math.abs(it.y - d.y) < 40 && it.x - d.x in 2f..90f }
                    .minByOrNull { it.x - d.x } ?: continue
                val v = (p.x - d.x) / dt
                if (v in 150f..1500f) speed = speed * 0.8f + v * 0.2f
            }
        }
        prevDets = dets; prevT = now

        val tap = TapService.instance ?: run { status = "Falta activar la accesibilidad"; return }
        val sx = curW / REF_W.toFloat(); val sy = curH / REF_H.toFloat()

        val inAir = now - lastJump < JUMP_LOCK_MS

        // --- saltar: buitre abajo ---
        if (!inAir) {
            val jumpThreat = dets.filter { it.low && it.x - PLAYER_X > -40f }
                .minByOrNull { it.x }
            if (jumpThreat != null && (jumpThreat.x - PLAYER_X) / speed <= JUMP_TTC) {
                lastJump = now; jumps++
                if (tap.isHolding()) {
                    tap.holdStop()
                    Handler(Looper.getMainLooper()).postDelayed({ tap.tap(UP_X * sx, UP_Y * sy) }, 90)
                } else {
                    tap.tap(UP_X * sx, UP_Y * sy)
                }
                duckUntil = 0
                return
            }
        }

        // --- agacharse: buitre arriba ---
        if (!inAir) {
            val duckThreat = dets.filter { !it.low && it.x - PLAYER_X > DUCK_RELEASE_DX }
                .minByOrNull { it.x }
            if (duckThreat != null && (duckThreat.x - PLAYER_X) / speed <= DUCK_TTC) duckUntil = now + 150
        }
        val wantDuck = now < duckUntil
        if (wantDuck && !tap.isHolding()) {
            tap.holdStart(DOWN_X * sx, DOWN_Y * sy)
            if (!wasDucking) ducks++
        }
        if (!wantDuck && tap.isHolding()) tap.holdStop()
        wasDucking = wantDuck
    }
}
