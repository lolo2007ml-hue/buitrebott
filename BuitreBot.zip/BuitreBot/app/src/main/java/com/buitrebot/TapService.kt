package com.buitrebot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

/** Hace los toques en pantalla. Se activa en Ajustes > Accesibilidad. */
class TapService : AccessibilityService() {

    companion object {
        @Volatile var instance: TapService? = null
    }

    private val main = Handler(Looper.getMainLooper())

    // --- mantener apretado (agacharse) ---
    @Volatile private var holding = false
    private var holdStroke: GestureDescription.StrokeDescription? = null
    private var hx = 0f
    private var hy = 0f

    private val holdCallback = object : GestureResultCallback() {
        override fun onCompleted(gestureDescription: GestureDescription?) {
            val prev = holdStroke ?: return
            if (holding) {
                val next = prev.continueStroke(pathAt(hx, hy), 0, 120, true)
                holdStroke = next
                dispatchGesture(GestureDescription.Builder().addStroke(next).build(), this, null)
            } else {
                val end = prev.continueStroke(pathAt(hx, hy), 0, 1, false)
                holdStroke = null
                dispatchGesture(GestureDescription.Builder().addStroke(end).build(), null, null)
            }
        }

        override fun onCancelled(gestureDescription: GestureDescription?) {
            holdStroke = null
            if (holding) {
                // si se cancela, lo reiniciamos
                holding = false
                holdStart(hx, hy)
            }
        }
    }

    private fun pathAt(x: Float, y: Float) = Path().apply { moveTo(x, y) }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** Toque corto (saltar). */
    fun tap(x: Float, y: Float, ms: Long = 60) {
        main.post {
            val s = GestureDescription.StrokeDescription(pathAt(x, y), 0, ms)
            dispatchGesture(GestureDescription.Builder().addStroke(s).build(), null, null)
        }
    }

    /** Empieza a mantener apretado (agacharse). */
    fun holdStart(x: Float, y: Float) {
        main.post {
            if (holding) return@post
            holding = true
            hx = x; hy = y
            val s = GestureDescription.StrokeDescription(pathAt(x, y), 0, 120, true)
            holdStroke = s
            dispatchGesture(GestureDescription.Builder().addStroke(s).build(), holdCallback, null)
        }
    }

    /** Suelta el botón. */
    fun holdStop() {
        main.post { holding = false }
    }

    fun isHolding() = holding
}
